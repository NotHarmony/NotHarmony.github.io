﻿using System;
using IIDKQuest.Classes;
using IIDKQuest.Mods;

namespace IIDKQuest.Menu
{
    // Token: 0x02000010 RID: 16
    internal class Buttons
    {
        // Token: 0x04000029 RID: 41
        public static ButtonInfo[][] buttons = new ButtonInfo[][]
        {
            new ButtonInfo[]
            {
                new ButtonInfo
                {
                    buttonText = "« <color=magenta>Made By Ropex</color> »",
                    method = delegate()
                    {
                        RigMods.PlaceHolder();
                    },
                    isTogglable = false,
                    toolTip = "@ropextherandom on discord."
                },
                new ButtonInfo
                {
                    buttonText = "« <color=magenta>Join Discord Server</color> »",
                    method = delegate()
                    {
                        RoomModsCat.JoinDiscord();
                    },
                    isTogglable = false,
                    toolTip = "Joins the Ropex Menu discord server."
                },
                new ButtonInfo
                {
                    buttonText = "« <color=magenta>Config</color> »",
                    method = delegate()
                    {
                        SettingsMods.EnterSettings();
                    },
                    isTogglable = false,
                    toolTip = "Opens the main settings page for the menu."
                },
                new ButtonInfo
                {
                    buttonText = "« <color=magenta>Movement Mods</color> »",
                    method = delegate()
                    {
                        SettingsMods.EnterMovementMods();
                    },
                    isTogglable = false,
                    toolTip = "Opens the main movement mods page for the menu."
                },
                new ButtonInfo
                {
                    buttonText = "« <color=magenta>Rig Mods</color> »",
                    method = delegate()
                    {
                        SettingsMods.EnterRigMods();
                    },
                    isTogglable = false,
                    toolTip = "Opens the main rig mods page for the menu."
                },
                new ButtonInfo
                {
                    buttonText = "« <color=magenta>Room Mods</color> »",
                    method = delegate()
                    {
                        SettingsMods.EnterRoomMods();
                    },
                    isTogglable = false,
                    toolTip = "Opens the main room mods page for the menu."
                },
                new ButtonInfo
                {
                    buttonText = "« <color=magenta>Fun Mods</color> »",
                    method = delegate()
                    {
                        SettingsMods.EnterFunMods();
                    },
                    isTogglable = false,
                    toolTip = "Opens the main fun mods page for the menu."
                },
                new ButtonInfo
                {
                    buttonText = "« <color=magenta>Visual Mods</color> »",
                    method = delegate()
                    {
                        SettingsMods.EnterVisualMods();
                    },
                    isTogglable = false,
                    toolTip = "Opens the main visual mods page for the menu."
                },
                new ButtonInfo
                {
                    buttonText = "« <color=magenta>Presets</color> »",
                    method = delegate()
                    {
                        SettingsMods.EnterPresets();
                    },
                    isTogglable = false,
                    toolTip = "Opens the main presets page for the menu."
                },
                new ButtonInfo
                {
                    buttonText = "« <color=red>Overpowered</color> <color=magenta>Mods</color> »",
                    method = delegate()
                    {
                        SettingsMods.OverpoweredMods();
                    },
                    isTogglable = false,
                    toolTip = "Opens the main presets page for the menu."
                }
            },
            new ButtonInfo[]
            {
                new ButtonInfo
                {
                    buttonText = "« <color=magenta>Exit</color> »",
                    method = delegate()
                    {
                        Global.ReturnHome();
                    },
                    isTogglable = false
                },
                new ButtonInfo
                {
                    buttonText = "Right Hand",
                    enableMethod = delegate()
                    {
                        SettingsMods.RightHand();
                    },
                    disableMethod = delegate()
                    {
                        SettingsMods.LeftHand();
                    }
                },
                new ButtonInfo
                {
                    buttonText = "FPS Counter",
                    enableMethod = delegate()
                    {
                        SettingsMods.EnableFPSCounter();
                    },
                    disableMethod = delegate()
                    {
                        SettingsMods.DisableFPSCounter();
                    },
                    enabled = Settings.fpsCounter
                },
                new ButtonInfo
                {
                    buttonText = "Disconnect Button",
                    enableMethod = delegate()
                    {
                        SettingsMods.EnableDisconnectButton();
                    },
                    disableMethod = delegate()
                    {
                        SettingsMods.DisableDisconnectButton();
                    },
                    enabled = Settings.disconnectButton
                },
                new ButtonInfo
                {
                    buttonText = "Menu MOTD",
                    enableMethod = delegate()
                    {
                        SettingsMods.CustomMOTDOff();
                    },
                    disableMethod = delegate()
                    {
                        SettingsMods.CustomMOTD();
                    },
                    enabled = Settings.customMotd
                },
                new ButtonInfo
                {
                    buttonText = "Purple To Black Menu",
                    enableMethod = delegate()
                    {
                        SettingsMods.RainbowMenuOff();
                    },
                    disableMethod = delegate()
                    {
                        SettingsMods.RainbowMenu();
                    }
                }
            },
            new ButtonInfo[]
            {
                new ButtonInfo
                {
                    buttonText = "« <color=magenta>Exit</color> »",
                    method = delegate()
                    {
                        Global.ReturnHome();
                    },
                    isTogglable = false
                },
                new ButtonInfo
                {
                    buttonText = "Platforms",
                    method = delegate()
                    {
                        MoveModsCat.Platforms();
                    }
                },
                new ButtonInfo
                {
                    buttonText = "Trigger Platforms",
                    method = delegate()
                    {
                        MoveModsCat.TriggerPlatforms();
                    }
                },
                new ButtonInfo
                {
                    buttonText = "Build Platforms",
                    method = delegate()
                    {
                        MoveModsCat.BuildPlatforms();
                    }
                },
                new ButtonInfo
                {
                    buttonText = "Trigger Build Platforms",
                    method = delegate()
                    {
                        MoveModsCat.TriggerBuildPlatforms();
                    }
                },
                new ButtonInfo
                {
                    buttonText = "Speed Boost",
                    method = delegate()
                    {
                        MoveModsCat.SpeedBoost();
                    }
                },
                new ButtonInfo
                {
                    buttonText = "Grip Speed Boost",
                    method = delegate()
                    {
                        MoveModsCat.GripSpeedBoost();
                    }
                },
                new ButtonInfo
                {
                    buttonText = "Mosa Speed Boost",
                    method = delegate()
                    {
                        LegitModsCat.MosaSpeed();
                    }
                },
                new ButtonInfo
                {
                    buttonText = "« <color=magenta>Exit</color> »",
                    method = delegate()
                    {
                        Global.ReturnHome();
                    },
                    isTogglable = false
                },
                new ButtonInfo
                {
                    buttonText = "Kill Tag Freeze",
                    method = delegate()
                    {
                        MoveModsCat.DisabletagFreeze();
                    }
                },
                new ButtonInfo
                {
                    buttonText = "Give Tag Freeze",
                    method = delegate()
                    {
                        MoveModsCat.EnableTagFreeze();
                    }
                },
                new ButtonInfo
                {
                    buttonText = "Fly",
                    method = delegate()
                    {
                        MoveModsCat.Fly();
                    }
                },
                new ButtonInfo
                {
                    buttonText = "Noclip Fly",
                    method = delegate()
                    {
                        MoveModsCat.NoclipFly();
                    }
                },
                new ButtonInfo
                {
                    buttonText = "Hand Fly",
                    method = delegate()
                    {
                        MoveModsCat.HandFly();
                    }
                },
                new ButtonInfo
                {
                    buttonText = "Trigger Fly",
                    method = delegate()
                    {
                        MoveModsCat.TriggerFly();
                    }
                },
                new ButtonInfo
                {
                    buttonText = "Trigger Hand Fly",
                    method = delegate()
                    {
                        MoveModsCat.TriggerHandFly();
                    }
                },
                new ButtonInfo
                {
                    buttonText = "« <color=magenta>Exit</color> »",
                    method = delegate()
                    {
                        Global.ReturnHome();
                    },
                    isTogglable = false
                },
                new ButtonInfo
                {
                    buttonText = "Slow Fly",
                    method = delegate()
                    {
                        MoveModsCat.SlowFly();
                    }
                },
                new ButtonInfo
                {
                    buttonText = "Low Gravity",
                    method = delegate()
                    {
                        MoveModsCat.LowGravity();
                    }
                },
                new ButtonInfo
                {
                    buttonText = "No Gravity",
                    method = delegate()
                    {
                        MoveModsCat.NoGravity();
                    }
                },
                new ButtonInfo
                {
                    buttonText = "High Gravity",
                    method = delegate()
                    {
                        MoveModsCat.HighGravity();
                    }
                },
                new ButtonInfo
                {
                    buttonText = "Loud Hand Taps",
                    method = delegate()
                    {
                        MoveModsCat.LoudTaps();
                    }
                },
                new ButtonInfo
                {
                    buttonText = "Silent Hand Taps",
                    method = delegate()
                    {
                        MoveModsCat.SilentTaps();
                    }
                },
                new ButtonInfo
                {
                    buttonText = "Weak Wall Walk",
                    method = delegate()
                    {
                        LegitModsCat.WeakWallWalk();
                    }
                },
                new ButtonInfo
                {
                    buttonText = "« <color=magenta>Exit</color> »",
                    method = delegate()
                    {
                        Global.ReturnHome();
                    },
                    isTogglable = false
                },
                new ButtonInfo
                {
                    buttonText = "Normal Wall Walk",
                    method = delegate()
                    {
                        LegitModsCat.WallWalk();
                    }
                },
                new ButtonInfo
                {
                    buttonText = "Strong Wall Walk",
                    method = delegate()
                    {
                        LegitModsCat.StrongWallWalk();
                    }
                },
                new ButtonInfo
                {
                    buttonText = "Up And Down",
                    method = delegate()
                    {
                        MoveModsCat.FastUpnDown();
                    }
                },
                new ButtonInfo
                {
                    buttonText = "Slow Up And Down",
                    method = delegate()
                    {
                        MoveModsCat.SlowUpnDown();
                    }
                },
                new ButtonInfo
                {
                    buttonText = "High Jump Helper [g]",
                    method = delegate()
                    {
                        MoveModsCat.HighJumpHelper();
                    }
                },
                new ButtonInfo
                {
                    buttonText = "Left And Right",
                    method = delegate()
                    {
                        MoveModsCat.FastLeftnRight();
                    }
                },
                new ButtonInfo
                {
                    buttonText = "Long Jump Helper",
                    method = delegate()
                    {
                        MoveModsCat.PSAFoward();
                    }
                },
                new ButtonInfo
                {
                    buttonText = "« <color=magenta>Exit</color> »",
                    method = delegate()
                    {
                        Global.ReturnHome();
                    },
                    isTogglable = false
                },
                new ButtonInfo
                {
                    buttonText = "Car Mode",
                    method = delegate()
                    {
                        MoveModsCat.Car();
                    }
                },
                new ButtonInfo
                {
                    buttonText = "Disable Velocity Cap",
                    method = delegate()
                    {
                        MoveModsCat.NoVelCap();
                    }
                }
            },
            new ButtonInfo[]
            {
                new ButtonInfo
                {
                    buttonText = "« <color=magenta>Exit</color> »",
                    method = delegate()
                    {
                        Global.ReturnHome();
                    },
                    isTogglable = false
                },
                new ButtonInfo
                {
                    buttonText = "Ghost Mode",
                    method = delegate()
                    {
                        RigMods.Ghost();
                    }
                },
                new ButtonInfo
                {
                    buttonText = "Invisible Mode",
                    method = delegate()
                    {
                        RigMods.Invis();
                    }
                },
                new ButtonInfo
                {
                    buttonText = "Steam Long Arms",
                    enableMethod = delegate()
                    {
                        RigMods.SteamLongArms();
                    },
                    disableMethod = delegate()
                    {
                        RigMods.ResetArms();
                    }
                },
                new ButtonInfo
                {
                    buttonText = "Really Long Arms",
                    enableMethod = delegate()
                    {
                        RigMods.ReallyLongArms();
                    },
                    disableMethod = delegate()
                    {
                        RigMods.ResetArms();
                    }
                },
                new ButtonInfo
                {
                    buttonText = "Minigames Kid Arms",
                    enableMethod = delegate()
                    {
                        RigMods.ShortArms();
                    },
                    disableMethod = delegate()
                    {
                        RigMods.ResetArms();
                    }
                },
                new ButtonInfo
                {
                    buttonText = "Stick Long Arms",
                    enableMethod = delegate()
                    {
                        RigMods.QuestLong();
                    },
                    disableMethod = delegate()
                    {
                        RigMods.ResetStickArms();
                    }
                },
                new ButtonInfo
                {
                    buttonText = "Noclip",
                    method = delegate()
                    {
                        RigMods.Noclip();
                    }
                },
                new ButtonInfo
                {
                    buttonText = "« <color=magenta>Exit</color> »",
                    method = delegate()
                    {
                        Global.ReturnHome();
                    },
                    isTogglable = false
                },
                new ButtonInfo
                {
                    buttonText = "Spin Head X",
                    enableMethod = delegate()
                    {
                        RigMods.SpinheadX();
                    },
                    disableMethod = delegate()
                    {
                        RigMods.FixHeadSPin();
                    }
                },
                new ButtonInfo
                {
                    buttonText = "Spin Head Y",
                    enableMethod = delegate()
                    {
                        RigMods.SpinheadY();
                    },
                    disableMethod = delegate()
                    {
                        RigMods.FixHeadSPin();
                    }
                },
                new ButtonInfo
                {
                    buttonText = "Spaz Head",
                    enableMethod = delegate()
                    {
                        RigMods.SpazHead();
                    },
                    disableMethod = delegate()
                    {
                        RigMods.FixHeadSPin();
                    }
                },
                new ButtonInfo
                {
                    buttonText = "Turn Head Position",
                    method = delegate()
                    {
                        RigMods.SpinheadX();
                    },
                    isTogglable = false
                }
            },
            new ButtonInfo[]
            {
                new ButtonInfo
                {
                    buttonText = "« <color=magenta>Exit</color> »",
                    method = delegate()
                    {
                        Global.ReturnHome();
                    },
                    isTogglable = false
                },
                new ButtonInfo
                {
                    buttonText = "Disconnect",
                    method = delegate()
                    {
                        RoomModsCat.Disconnect();
                    },
                    isTogglable = false
                },
                new ButtonInfo
                {
                    buttonText = "Reconnect",
                    method = delegate()
                    {
                        RoomModsCat.Rejoin();
                    },
                    isTogglable = false
                },
                new ButtonInfo
                {
                    buttonText = "Lobby Hop",
                    method = delegate()
                    {
                        RoomModsCat.LobbyHop();
                    },
                    isTogglable = false
                },
                new ButtonInfo
                {
                    buttonText = "Application Quit",
                    method = delegate()
                    {
                        RoomModsCat.QuitGame();
                    },
                    isTogglable = false
                },
                new ButtonInfo
                {
                    buttonText = "Join Menu Code",
                    method = delegate()
                    {
                        RoomModsCat.JoinMenuRoom();
                    },
                    isTogglable = false
                }
            },
            new ButtonInfo[]
            {
                new ButtonInfo
                {
                    buttonText = "« <color=magenta>Exit</color> »",
                    method = delegate()
                    {
                        Global.ReturnHome();
                    },
                    isTogglable = false
                },
                new ButtonInfo
                {
                    buttonText = "Disable Network Triggers [<color=red>CANT TURN OFF</color>}",
                    enableMethod = delegate()
                    {
                        RoomModsCat.DisableNetworkTriggers();
                    },
                    disableMethod = delegate()
                    {
                        RoomModsCat.EnableNetworkTriggers();
                    }
                },
                new ButtonInfo
                {
                    buttonText = "Fast Swim [<color=red>d?</color>]",
                    method = delegate()
                    {
                        RigMods.PlaceHolder();
                    }
                }
            },
            new ButtonInfo[]
            {
                new ButtonInfo
                {
                    buttonText = "« <color=magenta>Exit</color> »",
                    method = delegate()
                    {
                        Global.ReturnHome();
                    },
                    isTogglable = false
                },
                new ButtonInfo
                {
                    buttonText = "ESP",
                    method = delegate()
                    {
                        VisualModsCat.Esp();
                    }
                },
                new ButtonInfo
                {
                    buttonText = "Full Bright",
                    method = delegate()
                    {
                        VisualModsCat.FullBright();
                    }
                },
                new ButtonInfo
                {
                    buttonText = "Infection ESP",
                    method = delegate()
                    {
                        VisualModsCat.InfectionESP();
                    }
                }
            },
            new ButtonInfo[]
            {
                new ButtonInfo
                {
                    buttonText = "« <color=magenta>Exit</color> »",
                    method = delegate()
                    {
                        Global.ReturnHome();
                    },
                    isTogglable = false
                },
                new ButtonInfo
                {
                    buttonText = "H4kpy",
                    method = delegate()
                    {
                        PresetModsCat.h4kpy();
                    },
                    disableMethod = delegate()
                    {
                        RigMods.ResetArms();
                    }
                },
                new ButtonInfo
                {
                    buttonText = "TTTPig",
                    enableMethod = delegate()
                    {
                        PresetModsCat.tttpig();
                    },
                    disableMethod = delegate()
                    {
                        RigMods.ResetArms();
                    }
                },
                new ButtonInfo
                {
                    buttonText = "Ropex",
                    enableMethod = delegate()
                    {
                        PresetModsCat.ropex();
                    },
                    disableMethod = delegate()
                    {
                        RigMods.ResetArms();
                    }
                },
                new ButtonInfo
                {
                    buttonText = "Legit",
                    enableMethod = delegate()
                    {
                        PresetModsCat.legit();
                    },
                    disableMethod = delegate()
                    {
                        RigMods.ResetArms();
                    }
                }
            },
            new ButtonInfo[]
            {
                new ButtonInfo
                {
                    buttonText = "« <color=magenta>Exit</color> »",
                    method = delegate()
                    {
                        Global.ReturnHome();
                    },
                    isTogglable = false
                },
                new ButtonInfo
                {
                    buttonText = "Crash All",
                    method = delegate()
                    {
                        OverpoweredModsCat.CrashAll();
                    }
                },
                new ButtonInfo
                {
                    buttonText = "Destroy All",
                    enableMethod = delegate()
                    {
                        OverpoweredModsCat.DestroyAll();
                    },
                    isTogglable = false
                },
                new ButtonInfo
                {
                    buttonText = "Rig Spam",
                    method = delegate()
                    {
                        OverpoweredModsCat.RigSpam();
                    }
                },
                new ButtonInfo
                {
                    buttonText = "Set Lobby 100 Max Players",
                    method = delegate()
                    {
                        OverpoweredModsCat.AlotOfPlayers();
                    }
                },
                new ButtonInfo
                {
                    buttonText = "Set Master Client",
                    method = delegate()
                    {
                        OverpoweredModsCat.SetMaster();
                    }
                },
                new ButtonInfo
                {
                    buttonText = "Color Changer",
                    method = delegate()
                    {
                        OverpoweredModsCat.ColorChanger();
                    }
                },
                new ButtonInfo
                {
                    buttonText = "Cube Spammer [<color=magenta>SS</color>]",
                    method = delegate()
                    {
                        LegitModsCat.CubeSpammer();
                    }
                },
                new ButtonInfo
                {
                    buttonText = "Cube Gun [<color=magenta>SS</color>]",
                    method = delegate()
                    {
                        OverpoweredModsCat.CubeGun();
                    }
                },
                new ButtonInfo
                {
                    buttonText = "Target Spammer [<color=magenta>SS</color>]",
                    method = delegate()
                    {
                        OverpoweredModsCat.TargetSpam();
                    }
                },
                new ButtonInfo
                {
                    buttonText = "Target Gun [<color=magenta>SS</color>]",
                    method = delegate()
                    {
                        OverpoweredModsCat.TargetGun();
                    }
                },
                new ButtonInfo
                {
                    buttonText = "Low HZ",
                    method = delegate()
                    {
                        LegitModsCat.LowHZ();
                    }
                }
            }
        };
    }
}
