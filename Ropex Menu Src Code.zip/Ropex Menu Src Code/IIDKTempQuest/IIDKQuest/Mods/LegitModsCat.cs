﻿using System;
using easyInputs;
using GorillaLocomotion;
using Photon.Pun;
using UnityEngine;

namespace IIDKQuest.Mods
{
	// Token: 0x02000007 RID: 7
	internal class LegitModsCat
	{
		// Token: 0x06000010 RID: 16 RVA: 0x0000280D File Offset: 0x00000A0D
		public static void MosaSpeed()
		{
			Player.Instance.maxJumpSpeed = 6.5f;
			Player.Instance.jumpMultiplier = 1.5f;
		}

		// Token: 0x06000011 RID: 17 RVA: 0x00002830 File Offset: 0x00000A30
		public static void WeakWallWalk()
		{
			bool gripButtonDown = EasyInputs.GetGripButtonDown(EasyHand.RightHand);
			if (gripButtonDown)
			{
				Player.Instance.GetComponent<Rigidbody>().AddForce(new Vector3(0f, 0f, -5f), ForceMode.Acceleration);
			}
			bool gripButtonDown2 = EasyInputs.GetGripButtonDown(EasyHand.LeftHand);
			if (gripButtonDown2)
			{
				Player.Instance.GetComponent<Rigidbody>().AddForce(new Vector3(0f, 0f, 5f), ForceMode.Acceleration);
			}
		}

		// Token: 0x06000012 RID: 18 RVA: 0x000028A0 File Offset: 0x00000AA0
		public static void WallWalk()
		{
			bool gripButtonDown = EasyInputs.GetGripButtonDown(EasyHand.RightHand);
			if (gripButtonDown)
			{
				Player.Instance.GetComponent<Rigidbody>().AddForce(new Vector3(0f, 0f, -50f), ForceMode.Acceleration);
			}
			bool gripButtonDown2 = EasyInputs.GetGripButtonDown(EasyHand.LeftHand);
			if (gripButtonDown2)
			{
				Player.Instance.GetComponent<Rigidbody>().AddForce(new Vector3(0f, 0f, 50f), ForceMode.Acceleration);
			}
		}

		// Token: 0x06000013 RID: 19 RVA: 0x00002910 File Offset: 0x00000B10
		public static void StrongWallWalk()
		{
			bool gripButtonDown = EasyInputs.GetGripButtonDown(EasyHand.RightHand);
			if (gripButtonDown)
			{
				Player.Instance.GetComponent<Rigidbody>().AddForce(new Vector3(0f, 0f, -500f), ForceMode.Acceleration);
			}
			bool gripButtonDown2 = EasyInputs.GetGripButtonDown(EasyHand.LeftHand);
			if (gripButtonDown2)
			{
				Player.Instance.GetComponent<Rigidbody>().AddForce(new Vector3(0f, 0f, 500f), ForceMode.Acceleration);
			}
		}

		// Token: 0x06000014 RID: 20 RVA: 0x00002980 File Offset: 0x00000B80
		public static void LowHZ()
		{
			foreach (MeshCollider meshCollider in Resources.FindObjectsOfTypeAll<MeshCollider>())
			{
				meshCollider.enabled = true;
			}
		}

		// Token: 0x06000015 RID: 21 RVA: 0x000029D4 File Offset: 0x00000BD4
		public static void CubeSpammer()
		{
			bool gripButtonDown = EasyInputs.GetGripButtonDown(EasyHand.RightHand);
			if (gripButtonDown)
			{
				Vector3 position = Player.Instance.rightHandTransform.transform.position;
				Quaternion rotation = Player.Instance.rightHandTransform.transform.rotation;
				PhotonNetwork.Instantiate("bulletPrefab", position, rotation, 0, null).gameObject.GetComponent<Rigidbody>().useGravity = false;
			}
			bool gripButtonDown2 = EasyInputs.GetGripButtonDown(EasyHand.LeftHand);
			if (gripButtonDown2)
			{
				Vector3 position2 = Player.Instance.leftHandTransform.transform.position;
				Quaternion rotation2 = Player.Instance.leftHandTransform.transform.rotation;
				PhotonNetwork.Instantiate("bulletPrefab", position2, rotation2, 0, null).gameObject.GetComponent<Rigidbody>().useGravity = false;
			}
		}
	}
}
