﻿using System;

namespace IIDKQuest
{
    // Token: 0x02000003 RID: 3
    internal class PluginInfo
    {
        // Token: 0x0400000D RID: 13
        public const string GUID = "org.ropex.gorillatag.ropexmenu";

        // Token: 0x0400000E RID: 14
        public const string Name = "<b>Ropex Menu</b>";

        // Token: 0x0400000F RID: 15
        public const string Description = "Created by @ropextherandom on discord";

        // Token: 0x04000010 RID: 16
        public const string Version = "1.0.0";
    }
}
