﻿using System;
using Photon.Pun;
using UnityEngine;
using UnityEngine.UI;

namespace IIDKQuest.Mods
{
	// Token: 0x0200000C RID: 12
	internal class RoomModsCat
	{
		// Token: 0x06000052 RID: 82 RVA: 0x00004825 File Offset: 0x00002A25
		public static void Disconnect()
		{
			PhotonNetwork.Disconnect();
		}

		// Token: 0x06000053 RID: 83 RVA: 0x0000482E File Offset: 0x00002A2E
		public static void Rejoin()
		{
			PhotonNetwork.Reconnect();
		}

		// Token: 0x06000054 RID: 84 RVA: 0x00004837 File Offset: 0x00002A37
		public static void QuitGame()
		{
			Application.Quit();
		}

		// Token: 0x06000055 RID: 85 RVA: 0x00004840 File Offset: 0x00002A40
		public static void Motd()
		{
			bool customMotd = Settings.customMotd;
			if (customMotd)
			{
				GameObject.Find("motdtext").GetComponent<Text>().text = "THANK YOU FOR USING <color=green>Ropex Menu</color>! Make sure to join the discord server to make sure you have the most recent and undetected version of the menu! <color=blue>https://discord.gg/AdZCvpHp</color>. If you think this menu is a <color=red>RAT</color> or contains any <color=red>malware</color>, this menu is fully open source and free!";
			}
		}

		// Token: 0x06000056 RID: 86 RVA: 0x00004873 File Offset: 0x00002A73
		public static void JoinRandomRoom()
		{
			PhotonNetwork.JoinRandomRoom();
		}

		// Token: 0x06000057 RID: 87 RVA: 0x0000487C File Offset: 0x00002A7C
		public static void hz()
		{
			Application.targetFrameRate = 60;
		}

		// Token: 0x06000058 RID: 88 RVA: 0x00004887 File Offset: 0x00002A87
		public static void JoinDiscord()
		{
			Application.OpenURL("https://discord.gg/bG2ZUwFhnF");
		}

		// Token: 0x06000059 RID: 89 RVA: 0x00004895 File Offset: 0x00002A95
		public static void LobbyHop()
		{
			PhotonNetwork.Disconnect();
			PhotonNetwork.JoinRandomRoom();
		}

		// Token: 0x0600005A RID: 90 RVA: 0x000048A4 File Offset: 0x00002AA4
		public static void JoinMenuRoom()
		{
			PhotonNetwork.JoinRoom("ROPEXMENU", null);
		}

		// Token: 0x0600005B RID: 91 RVA: 0x000048B3 File Offset: 0x00002AB3
		public static void DisableNetworkTriggers()
		{
			GameObject.Find("JoinRoomTriggers_Prefab").SetActive(false);
		}

		// Token: 0x0600005C RID: 92 RVA: 0x000048C7 File Offset: 0x00002AC7
		public static void EnableNetworkTriggers()
		{
			GameObject.Find("JoinRoomTriggers_Prefab").SetActive(true);
		}
	}
}
