﻿using System;
using IIDKQuest.Classes;
using UnityEngine;

namespace IIDKQuest
{
    // Token: 0x02000002 RID: 2
    internal class Settings
    {
        // Token: 0x04000001 RID: 1
        public static ExtGradient backgroundColor = new ExtGradient
        {
            isRainbow = true
        };

        // Token: 0x04000002 RID: 2
        public static ExtGradient[] buttonColors = new ExtGradient[]
        {
            new ExtGradient
            {
                isRainbow = true
            },
            new ExtGradient
            {
                isRainbow = true
            }
        };

        // Token: 0x04000003 RID: 3
        public static Color[] textColors = new Color[]
        {
            Color.white,
            Color.magenta
        };

        // Token: 0x04000004 RID: 4
        public static Font currentFont = Resources.GetBuiltinResource<Font>("Arial.ttf");

        // Token: 0x04000005 RID: 5
        public static bool fpsCounter = true;

        // Token: 0x04000006 RID: 6
        public static bool disconnectButton = true;

        // Token: 0x04000007 RID: 7
        public static bool rightHanded = false;

        // Token: 0x04000008 RID: 8
        public static bool disableNotifications = true;

        // Token: 0x04000009 RID: 9
        public static bool customMotd = true;

        // Token: 0x0400000A RID: 10
        public static KeyCode keyboardButton = KeyCode.Q;

        // Token: 0x0400000B RID: 11
        public static Vector3 menuSize = new Vector3(0.1f, 1f, 1f);

        // Token: 0x0400000C RID: 12
        public static int buttonsPerPage = 8;
    }
}
