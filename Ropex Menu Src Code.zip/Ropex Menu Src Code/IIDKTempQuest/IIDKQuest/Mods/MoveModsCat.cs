﻿using System;
using easyInputs;
using GorillaLocomotion;
using UnityEngine;

namespace IIDKQuest.Mods
{
	// Token: 0x02000008 RID: 8
	internal class MoveModsCat
	{
		// Token: 0x06000017 RID: 23 RVA: 0x00002A9C File Offset: 0x00000C9C
		public static void Platforms()
		{
			bool gripButtonDown = EasyInputs.GetGripButtonDown(EasyHand.LeftHand);
			bool flag = gripButtonDown;
			if (flag)
			{
				bool flag2 = !MoveModsCat.PlatLEnabled;
				bool flag3 = flag2;
				if (flag3)
				{
					MoveModsCat.PlatL = GameObject.CreatePrimitive(PrimitiveType.Cube);
					bool flag4 = ColorUtility.TryParseHtmlString(MoveModsCat.hexColorCode, out MoveModsCat.newColor);
					bool flag5 = flag4;
					if (flag5)
					{
						MoveModsCat.PlatL.GetComponent<Renderer>().material.color = MoveModsCat.newColor;
						MoveModsCat.PlatL.GetComponent<MeshRenderer>().enabled = true;
					}
					MoveModsCat.PlatL.transform.localScale = new Vector3(0.3f, 0.02f, 0.3f);
					MoveModsCat.PlatL.transform.position = GorillaTagger.Instance.leftHandTransform.position + new Vector3(0f, -0.07f, 0f);
					MoveModsCat.PlatL.transform.rotation = GorillaTagger.Instance.leftHandTransform.rotation * Quaternion.Euler(0f, 0f, -90f);
					MoveModsCat.PlatLEnabled = true;
				}
			}
			else
			{
				bool platLEnabled = MoveModsCat.PlatLEnabled;
				bool flag6 = platLEnabled;
				if (flag6)
				{
					UnityEngine.Object.Destroy(MoveModsCat.PlatL);
					MoveModsCat.PlatLEnabled = false;
				}
			}
			bool gripButtonDown2 = EasyInputs.GetGripButtonDown(EasyHand.RightHand);
			bool flag7 = gripButtonDown2;
			if (flag7)
			{
				bool flag8 = !MoveModsCat.PlatREnabled;
				bool flag9 = flag8;
				if (flag9)
				{
					MoveModsCat.PlatR = GameObject.CreatePrimitive(PrimitiveType.Cube);
					bool flag10 = ColorUtility.TryParseHtmlString(MoveModsCat.hexColorCode, out MoveModsCat.newColor);
					bool flag11 = flag10;
					if (flag11)
					{
						MoveModsCat.PlatR.GetComponent<Renderer>().material.color = MoveModsCat.newColor;
						MoveModsCat.PlatR.GetComponent<MeshRenderer>().enabled = true;
					}
					MoveModsCat.PlatR.transform.localScale = new Vector3(0.3f, 0.02f, 0.3f);
					MoveModsCat.PlatR.transform.position = GorillaTagger.Instance.rightHandTransform.position + new Vector3(0f, -0.07f, 0f);
					MoveModsCat.PlatR.transform.rotation = GorillaTagger.Instance.rightHandTransform.rotation * Quaternion.Euler(0f, 0f, -90f);
					MoveModsCat.PlatREnabled = true;
					MoveModsCat.PlatLEnabled = true;
				}
			}
			else
			{
				bool platREnabled = MoveModsCat.PlatREnabled;
				bool flag12 = platREnabled;
				if (flag12)
				{
					UnityEngine.Object.Destroy(MoveModsCat.PlatR);
					MoveModsCat.PlatREnabled = false;
				}
			}
		}

		// Token: 0x06000018 RID: 24 RVA: 0x00002D22 File Offset: 0x00000F22
		public static void SpeedBoost()
		{
			Player.Instance.maxJumpSpeed = 9f;
			Player.Instance.jumpMultiplier = 9f;
		}

		// Token: 0x06000019 RID: 25 RVA: 0x00002D45 File Offset: 0x00000F45
		public static void NoVelCap()
		{
			Player.Instance.maxJumpSpeed = 99999f;
		}

		// Token: 0x0600001A RID: 26 RVA: 0x00002D58 File Offset: 0x00000F58
		public static void GripSpeedBoost()
		{
			bool gripButtonDown = EasyInputs.GetGripButtonDown(EasyHand.RightHand);
			if (gripButtonDown)
			{
				Player.Instance.maxJumpSpeed = 9f;
				Player.Instance.jumpMultiplier = 9f;
			}
		}

		// Token: 0x0600001B RID: 27 RVA: 0x00002D92 File Offset: 0x00000F92
		public static void DisabletagFreeze()
		{
			Player.Instance.disableMovement = false;
		}

		// Token: 0x0600001C RID: 28 RVA: 0x00002DA1 File Offset: 0x00000FA1
		public static void EnableTagFreeze()
		{
			Player.Instance.disableMovement = true;
		}

		// Token: 0x0600001D RID: 29 RVA: 0x00002DB0 File Offset: 0x00000FB0
		public static void LoudTaps()
		{
			GorillaTagger.Instance.handTapVolume = 15f;
		}

		// Token: 0x0600001E RID: 30 RVA: 0x00002DC3 File Offset: 0x00000FC3
		public static void ResetTaps()
		{
			GorillaTagger.Instance.handTapVolume = 0.1f;
		}

		// Token: 0x0600001F RID: 31 RVA: 0x00002DD6 File Offset: 0x00000FD6
		public static void SilentTaps()
		{
			GorillaTagger.Instance.handTapVolume = 0f;
		}

		// Token: 0x06000020 RID: 32 RVA: 0x00002DEC File Offset: 0x00000FEC
		public static void PSAFoward()
		{
			bool secondaryButtonDown = EasyInputs.GetSecondaryButtonDown(EasyHand.RightHand);
			if (secondaryButtonDown)
			{
				Player.Instance.transform.position += Player.Instance.headCollider.transform.forward * Time.deltaTime * 2f;
			}
		}

		// Token: 0x06000021 RID: 33 RVA: 0x00002E4C File Offset: 0x0000104C
		public static void Fly()
		{
			bool primaryButtonDown = EasyInputs.GetPrimaryButtonDown(EasyHand.RightHand);
			if (primaryButtonDown)
			{
				Player.Instance.transform.position += Player.Instance.headCollider.transform.forward * Time.deltaTime * 15f;
				Player.Instance.GetComponent<Rigidbody>().velocity = Vector3.zero;
			}
		}

		// Token: 0x06000022 RID: 34 RVA: 0x00002EC0 File Offset: 0x000010C0
		public static void FastUpnDown()
		{
			bool gripButtonDown = EasyInputs.GetGripButtonDown(EasyHand.LeftHand);
			if (gripButtonDown)
			{
				Player.Instance.GetComponent<Rigidbody>().AddForce(new Vector3(0f, -500f, 0f), ForceMode.Acceleration);
			}
			bool gripButtonDown2 = EasyInputs.GetGripButtonDown(EasyHand.RightHand);
			if (gripButtonDown2)
			{
				Player.Instance.GetComponent<Rigidbody>().AddForce(new Vector3(0f, 500f, 0f), ForceMode.Acceleration);
			}
		}

		// Token: 0x06000023 RID: 35 RVA: 0x00002F30 File Offset: 0x00001130
		public static void LowGravity()
		{
			Player.Instance.bodyCollider.attachedRigidbody.AddForce(Vector3.up * (Time.deltaTime * (6.5f / Time.deltaTime)), ForceMode.Acceleration);
		}

		// Token: 0x06000024 RID: 36 RVA: 0x00002F64 File Offset: 0x00001164
		public static void NoGravity()
		{
			Player.Instance.GetComponent<Rigidbody>().AddForce(-Physics.gravity, ForceMode.Acceleration);
		}

		// Token: 0x06000025 RID: 37 RVA: 0x00002F82 File Offset: 0x00001182
		public static void HighGravity()
		{
			Player.Instance.bodyCollider.attachedRigidbody.AddForce(Vector3.down * (Time.deltaTime * (14f / Time.deltaTime)), ForceMode.Acceleration);
		}

		// Token: 0x06000026 RID: 38 RVA: 0x00002FB8 File Offset: 0x000011B8
		public static void TriggerFly()
		{
			bool triggerButtonDown = EasyInputs.GetTriggerButtonDown(EasyHand.LeftHand);
			if (triggerButtonDown)
			{
				Player.Instance.transform.position += Player.Instance.headCollider.transform.forward * Time.deltaTime * 15f;
				Player.Instance.GetComponent<Rigidbody>().velocity = Vector3.zero;
			}
		}

		// Token: 0x06000027 RID: 39 RVA: 0x0000302C File Offset: 0x0000122C
		public static void TriggerHandFly()
		{
			bool triggerButtonDown = EasyInputs.GetTriggerButtonDown(EasyHand.LeftHand);
			if (triggerButtonDown)
			{
				Player.Instance.transform.position += GorillaTagger.Instance.rightHandTransform.transform.forward * Time.deltaTime * 15f;
				Player.Instance.GetComponent<Rigidbody>().velocity = Vector3.zero;
			}
		}

		// Token: 0x06000028 RID: 40 RVA: 0x000030A0 File Offset: 0x000012A0
		public static void HandFly()
		{
			bool primaryButtonDown = EasyInputs.GetPrimaryButtonDown(EasyHand.RightHand);
			if (primaryButtonDown)
			{
				Player.Instance.transform.position += GorillaTagger.Instance.rightHandTransform.transform.forward * Time.deltaTime * 15f;
				Player.Instance.GetComponent<Rigidbody>().velocity = Vector3.zero;
			}
		}

		// Token: 0x06000029 RID: 41 RVA: 0x00003114 File Offset: 0x00001314
		public static void FastLeftnRight()
		{
			bool gripButtonDown = EasyInputs.GetGripButtonDown(EasyHand.LeftHand);
			if (gripButtonDown)
			{
				Player.Instance.GetComponent<Rigidbody>().AddForce(new Vector3(0f, 0f, -500f), ForceMode.Acceleration);
			}
			bool gripButtonDown2 = EasyInputs.GetGripButtonDown(EasyHand.RightHand);
			if (gripButtonDown2)
			{
				Player.Instance.GetComponent<Rigidbody>().AddForce(new Vector3(0f, 0f, 500f), ForceMode.Acceleration);
			}
		}

		// Token: 0x0600002A RID: 42 RVA: 0x00003184 File Offset: 0x00001384
		public static void BuildPlatforms()
		{
			bool gripButtonDown = EasyInputs.GetGripButtonDown(EasyHand.LeftHand);
			bool flag = gripButtonDown;
			if (flag)
			{
				bool flag2 = !MoveModsCat.PlatLEnabled;
				bool flag3 = flag2;
				if (flag3)
				{
					MoveModsCat.PlatL = GameObject.CreatePrimitive(PrimitiveType.Cube);
					bool flag4 = ColorUtility.TryParseHtmlString(MoveModsCat.hexColorCode, out MoveModsCat.newColor);
					bool flag5 = flag4;
					if (flag5)
					{
						MoveModsCat.PlatL.GetComponent<Renderer>().material.color = MoveModsCat.newColor;
						MoveModsCat.PlatL.GetComponent<MeshRenderer>().enabled = true;
					}
					MoveModsCat.PlatL.transform.localScale = new Vector3(0.3f, 0.02f, 0.3f);
					MoveModsCat.PlatL.transform.position = GorillaTagger.Instance.leftHandTransform.position + new Vector3(0f, -0.07f, 0f);
					MoveModsCat.PlatL.transform.rotation = GorillaTagger.Instance.leftHandTransform.rotation * Quaternion.Euler(0f, 0f, -90f);
					MoveModsCat.PlatLEnabled = true;
				}
			}
			else
			{
				bool platLEnabled = MoveModsCat.PlatLEnabled;
				bool flag6 = platLEnabled;
				if (flag6)
				{
					MoveModsCat.PlatLEnabled = false;
				}
			}
			bool gripButtonDown2 = EasyInputs.GetGripButtonDown(EasyHand.RightHand);
			bool flag7 = gripButtonDown2;
			if (flag7)
			{
				bool flag8 = !MoveModsCat.PlatREnabled;
				bool flag9 = flag8;
				if (flag9)
				{
					MoveModsCat.PlatR = GameObject.CreatePrimitive(PrimitiveType.Cube);
					bool flag10 = ColorUtility.TryParseHtmlString(MoveModsCat.hexColorCode, out MoveModsCat.newColor);
					bool flag11 = flag10;
					if (flag11)
					{
						MoveModsCat.PlatR.GetComponent<Renderer>().material.color = MoveModsCat.newColor;
						MoveModsCat.PlatR.GetComponent<MeshRenderer>().enabled = true;
					}
					MoveModsCat.PlatR.transform.localScale = new Vector3(0.3f, 0.02f, 0.3f);
					MoveModsCat.PlatR.transform.position = GorillaTagger.Instance.rightHandTransform.position + new Vector3(0f, -0.07f, 0f);
					MoveModsCat.PlatR.transform.rotation = GorillaTagger.Instance.rightHandTransform.rotation * Quaternion.Euler(0f, 0f, -90f);
					MoveModsCat.PlatREnabled = true;
					MoveModsCat.PlatLEnabled = true;
				}
			}
			else
			{
				bool platREnabled = MoveModsCat.PlatREnabled;
				bool flag12 = platREnabled;
				if (flag12)
				{
					MoveModsCat.PlatREnabled = false;
				}
			}
		}

		// Token: 0x0600002B RID: 43 RVA: 0x000033F4 File Offset: 0x000015F4
		public static void SlowUpnDown()
		{
			bool gripButtonDown = EasyInputs.GetGripButtonDown(EasyHand.LeftHand);
			if (gripButtonDown)
			{
				Player.Instance.GetComponent<Rigidbody>().AddForce(new Vector3(0f, -30f, 0f), ForceMode.Acceleration);
			}
			bool gripButtonDown2 = EasyInputs.GetGripButtonDown(EasyHand.RightHand);
			if (gripButtonDown2)
			{
				Player.Instance.GetComponent<Rigidbody>().AddForce(new Vector3(0f, 30f, 0f), ForceMode.Acceleration);
			}
		}

		// Token: 0x0600002C RID: 44 RVA: 0x00003464 File Offset: 0x00001664
		public static void Car()
		{
			bool primaryButtonDown = EasyInputs.GetPrimaryButtonDown(EasyHand.RightHand);
			if (primaryButtonDown)
			{
				Player.Instance.transform.position += Player.Instance.headCollider.transform.forward * Time.deltaTime * 25f;
			}
		}

		// Token: 0x0600002D RID: 45 RVA: 0x000034C4 File Offset: 0x000016C4
		public static void SlowFly()
		{
			bool primaryButtonDown = EasyInputs.GetPrimaryButtonDown(EasyHand.RightHand);
			if (primaryButtonDown)
			{
				Player.Instance.transform.position += Player.Instance.headCollider.transform.forward * Time.deltaTime * 3f;
				Player.Instance.GetComponent<Rigidbody>().velocity = Vector3.zero;
			}
		}

		// Token: 0x0600002E RID: 46 RVA: 0x00003538 File Offset: 0x00001738
		public static void HighJumpHelper()
		{
			bool gripButtonDown = EasyInputs.GetGripButtonDown(EasyHand.RightHand);
			if (gripButtonDown)
			{
				Player.Instance.GetComponent<Rigidbody>().AddForce(new Vector3(0f, 5f, 0f), ForceMode.Acceleration);
			}
		}

		// Token: 0x0600002F RID: 47 RVA: 0x00003578 File Offset: 0x00001778
		public static void TriggerPlatforms()
		{
			bool triggerButtonDown = EasyInputs.GetTriggerButtonDown(EasyHand.LeftHand);
			bool flag = triggerButtonDown;
			if (flag)
			{
				bool flag2 = !MoveModsCat.PlatLEnabled;
				bool flag3 = flag2;
				if (flag3)
				{
					MoveModsCat.PlatL = GameObject.CreatePrimitive(PrimitiveType.Cube);
					bool flag4 = ColorUtility.TryParseHtmlString(MoveModsCat.hexColorCode, out MoveModsCat.newColor);
					bool flag5 = flag4;
					if (flag5)
					{
						MoveModsCat.PlatL.GetComponent<Renderer>().material.color = MoveModsCat.newColor;
						MoveModsCat.PlatL.GetComponent<MeshRenderer>().enabled = true;
					}
					MoveModsCat.PlatL.transform.localScale = new Vector3(0.3f, 0.02f, 0.3f);
					MoveModsCat.PlatL.transform.position = GorillaTagger.Instance.leftHandTransform.position + new Vector3(0f, -0.07f, 0f);
					MoveModsCat.PlatL.transform.rotation = GorillaTagger.Instance.leftHandTransform.rotation * Quaternion.Euler(0f, 0f, -90f);
					MoveModsCat.PlatLEnabled = true;
				}
			}
			else
			{
				bool platLEnabled = MoveModsCat.PlatLEnabled;
				bool flag6 = platLEnabled;
				if (flag6)
				{
					UnityEngine.Object.Destroy(MoveModsCat.PlatL);
					MoveModsCat.PlatLEnabled = false;
				}
			}
			bool gripButtonDown = EasyInputs.GetGripButtonDown(EasyHand.RightHand);
			bool flag7 = gripButtonDown;
			if (flag7)
			{
				bool flag8 = !MoveModsCat.PlatREnabled;
				bool flag9 = flag8;
				if (flag9)
				{
					MoveModsCat.PlatR = GameObject.CreatePrimitive(PrimitiveType.Cube);
					bool flag10 = ColorUtility.TryParseHtmlString(MoveModsCat.hexColorCode, out MoveModsCat.newColor);
					bool flag11 = flag10;
					if (flag11)
					{
						MoveModsCat.PlatR.GetComponent<Renderer>().material.color = MoveModsCat.newColor;
						MoveModsCat.PlatR.GetComponent<MeshRenderer>().enabled = true;
					}
					MoveModsCat.PlatR.transform.localScale = new Vector3(0.3f, 0.02f, 0.3f);
					MoveModsCat.PlatR.transform.position = GorillaTagger.Instance.rightHandTransform.position + new Vector3(0f, -0.07f, 0f);
					MoveModsCat.PlatR.transform.rotation = GorillaTagger.Instance.rightHandTransform.rotation * Quaternion.Euler(0f, 0f, -90f);
					MoveModsCat.PlatREnabled = true;
					MoveModsCat.PlatLEnabled = true;
				}
			}
			else
			{
				bool platREnabled = MoveModsCat.PlatREnabled;
				bool flag12 = platREnabled;
				if (flag12)
				{
					UnityEngine.Object.Destroy(MoveModsCat.PlatR);
					MoveModsCat.PlatREnabled = false;
				}
			}
		}

		// Token: 0x06000030 RID: 48 RVA: 0x00003800 File Offset: 0x00001A00
		public static void TriggerBuildPlatforms()
		{
			bool triggerButtonDown = EasyInputs.GetTriggerButtonDown(EasyHand.LeftHand);
			bool flag = triggerButtonDown;
			if (flag)
			{
				bool flag2 = !MoveModsCat.PlatLEnabled;
				bool flag3 = flag2;
				if (flag3)
				{
					MoveModsCat.PlatL = GameObject.CreatePrimitive(PrimitiveType.Cube);
					bool flag4 = ColorUtility.TryParseHtmlString(MoveModsCat.hexColorCode, out MoveModsCat.newColor);
					bool flag5 = flag4;
					if (flag5)
					{
						MoveModsCat.PlatL.GetComponent<Renderer>().material.color = MoveModsCat.newColor;
						MoveModsCat.PlatL.GetComponent<MeshRenderer>().enabled = true;
					}
					MoveModsCat.PlatL.transform.localScale = new Vector3(0.3f, 0.02f, 0.3f);
					MoveModsCat.PlatL.transform.position = GorillaTagger.Instance.leftHandTransform.position + new Vector3(0f, -0.07f, 0f);
					MoveModsCat.PlatL.transform.rotation = GorillaTagger.Instance.leftHandTransform.rotation * Quaternion.Euler(0f, 0f, -90f);
					MoveModsCat.PlatLEnabled = true;
				}
			}
			else
			{
				bool platLEnabled = MoveModsCat.PlatLEnabled;
				bool flag6 = platLEnabled;
				if (flag6)
				{
					MoveModsCat.PlatLEnabled = false;
				}
			}
			bool triggerButtonDown2 = EasyInputs.GetTriggerButtonDown(EasyHand.RightHand);
			bool flag7 = triggerButtonDown2;
			if (flag7)
			{
				bool flag8 = !MoveModsCat.PlatREnabled;
				bool flag9 = flag8;
				if (flag9)
				{
					MoveModsCat.PlatR = GameObject.CreatePrimitive(PrimitiveType.Cube);
					bool flag10 = ColorUtility.TryParseHtmlString(MoveModsCat.hexColorCode, out MoveModsCat.newColor);
					bool flag11 = flag10;
					if (flag11)
					{
						MoveModsCat.PlatR.GetComponent<Renderer>().material.color = MoveModsCat.newColor;
						MoveModsCat.PlatR.GetComponent<MeshRenderer>().enabled = true;
					}
					MoveModsCat.PlatR.transform.localScale = new Vector3(0.3f, 0.02f, 0.3f);
					MoveModsCat.PlatR.transform.position = GorillaTagger.Instance.rightHandTransform.position + new Vector3(0f, -0.07f, 0f);
					MoveModsCat.PlatR.transform.rotation = GorillaTagger.Instance.rightHandTransform.rotation * Quaternion.Euler(0f, 0f, -90f);
					MoveModsCat.PlatREnabled = true;
					MoveModsCat.PlatLEnabled = true;
				}
			}
			else
			{
				bool platREnabled = MoveModsCat.PlatREnabled;
				bool flag12 = platREnabled;
				if (flag12)
				{
					MoveModsCat.PlatREnabled = false;
				}
			}
		}

		// Token: 0x06000031 RID: 49 RVA: 0x00003A70 File Offset: 0x00001C70
		public static void NoclipFly()
		{
			bool primaryButtonDown = EasyInputs.GetPrimaryButtonDown(EasyHand.RightHand);
			if (primaryButtonDown)
			{
				Player.Instance.transform.position += Player.Instance.headCollider.transform.forward * Time.deltaTime * 15f;
				Player.Instance.GetComponent<Rigidbody>().velocity = Vector3.zero;
				foreach (Collider collider in UnityEngine.Object.FindObjectsOfType<MeshCollider>())
				{
					collider.enabled = false;
				}
				foreach (Collider collider2 in UnityEngine.Object.FindObjectsOfType<BoxCollider>())
				{
					collider2.enabled = false;
				}
				foreach (Collider collider3 in UnityEngine.Object.FindObjectsOfType<SphereCollider>())
				{
					collider3.enabled = false;
				}
				foreach (BoxCollider boxCollider in Resources.FindObjectsOfTypeAll<BoxCollider>())
				{
					boxCollider.enabled = false;
				}
			}
			else
			{
				foreach (Collider collider4 in UnityEngine.Object.FindObjectsOfType<MeshCollider>())
				{
					collider4.enabled = true;
				}
				foreach (Collider collider5 in UnityEngine.Object.FindObjectsOfType<BoxCollider>())
				{
					collider5.enabled = true;
				}
				foreach (Collider collider6 in UnityEngine.Object.FindObjectsOfType<SphereCollider>())
				{
					collider6.enabled = true;
				}
				foreach (BoxCollider boxCollider2 in Resources.FindObjectsOfTypeAll<BoxCollider>())
				{
					boxCollider2.enabled = true;
				}
			}
		}

		// Token: 0x06000032 RID: 50 RVA: 0x00003D1C File Offset: 0x00001F1C
		public static void ClearPlatforms()
		{
			MoveModsCat.PlatREnabled = false;
			MoveModsCat.PlatLEnabled = false;
			UnityEngine.Object.Destroy(MoveModsCat.PlatL);
			UnityEngine.Object.Destroy(MoveModsCat.PlatR);
		}

		// Token: 0x04000021 RID: 33
		public static GameObject PlatL;

		// Token: 0x04000022 RID: 34
		public static bool PlatLEnabled;

		// Token: 0x04000023 RID: 35
		public static GameObject PlatR;

		// Token: 0x04000024 RID: 36
		public static bool PlatREnabled;

		// Token: 0x04000025 RID: 37
		private static string hexColorCode;

		// Token: 0x04000026 RID: 38
		private static Color newColor;

		// Token: 0x04000027 RID: 39
		public bool platL;

		// Token: 0x04000028 RID: 40
		public bool platR;
	}
}
