﻿using System;
using UnityEngine;

namespace IIDKQuest.Mods
{
	// Token: 0x0200000F RID: 15
	internal class VisualModsCat
	{
		// Token: 0x06000075 RID: 117 RVA: 0x000049FC File Offset: 0x00002BFC
		public static void Esp()
		{
			foreach (VRRig vrrig in UnityEngine.Object.FindObjectsOfType<VRRig>())
			{
				vrrig.mainSkin.material.color = Color.magenta;
				vrrig.mainSkin.material.shader = Shader.Find("GUI/Text Shader");
			}
		}

		// Token: 0x06000076 RID: 118 RVA: 0x00004A78 File Offset: 0x00002C78
		public static void BugESP()
		{
		}

		// Token: 0x06000077 RID: 119 RVA: 0x00004A7C File Offset: 0x00002C7C
		public static void InfectionESP()
		{
			foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
			{
				bool flag = !vrrig.isOfflineVRRig && !vrrig.isMyPlayer;
				bool flag2 = flag;
				if (flag2)
				{
					bool flag3 = vrrig.mainSkin.material.name.Contains("fected");
					bool flag4 = flag3;
					if (flag4)
					{
						vrrig.mainSkin.material.shader = Shader.Find("GUI/Text Shader");
						vrrig.mainSkin.material.color = new Color(1f, 0f, 0f, 0.4f);
					}
					else
					{
						vrrig.mainSkin.material.shader = Shader.Find("GUI/Text Shader");
						vrrig.mainSkin.material.color = new Color(1f, 0f, 1f, 0.4f);
					}
				}
			}
			foreach (VRRig vrrig2 in GorillaParent.instance.vrrigs)
			{
				bool flag5 = !vrrig2.isOfflineVRRig && !vrrig2.isMyPlayer;
				bool flag6 = flag5;
				if (flag6)
				{
					bool flag7 = vrrig2.mainSkin.material.name.Contains("fected");
					bool flag8 = flag7;
					if (flag8)
					{
						vrrig2.mainSkin.material.shader = Shader.Find("GUI/Text Shader");
						vrrig2.mainSkin.material.color = new Color(1f, 1f, 0f, 0.4f);
					}
					else
					{
						vrrig2.mainSkin.material.shader = Shader.Find("GUI/Text Shader");
						vrrig2.mainSkin.material.color = new Color(1f, 0f, 1f, 0.4f);
					}
				}
			}
		}

		// Token: 0x06000078 RID: 120 RVA: 0x00004C93 File Offset: 0x00002E93
		public static void FullBright()
		{
			RenderSettings.fog = false;
			RenderSettings.ambientLight = Color.white;
		}
	}
}
