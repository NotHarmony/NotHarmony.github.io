﻿using System;
using GorillaLocomotion;
using UnityEngine;

namespace IIDKQuest.Mods
{
	// Token: 0x0200000A RID: 10
	internal class PresetModsCat
	{
		// Token: 0x0600003E RID: 62 RVA: 0x000042B4 File Offset: 0x000024B4
		public static void h4kpy()
		{
			Player.Instance.transform.localScale = new Vector3(1.2f, 1.2f, 1.2f);
			Player.Instance.maxJumpSpeed = 6.5f;
			Player.Instance.jumpMultiplier = 1.5f;
		}

		// Token: 0x0600003F RID: 63 RVA: 0x00004308 File Offset: 0x00002508
		public static void tttpig()
		{
			Player.Instance.transform.localScale = new Vector3(1.1f, 1.1f, 1.1f);
			Player.Instance.maxJumpSpeed = 5f;
			Player.Instance.jumpMultiplier = 1.4f;
		}

		// Token: 0x06000040 RID: 64 RVA: 0x0000435C File Offset: 0x0000255C
		public static void ropex()
		{
			Player.Instance.transform.localScale = new Vector3(1.25f, 1.25f, 1.25f);
			Player.Instance.maxJumpSpeed = 15f;
			Player.Instance.jumpMultiplier = 10f;
		}

		// Token: 0x06000041 RID: 65 RVA: 0x000043AE File Offset: 0x000025AE
		public static void legit()
		{
			Player.Instance.transform.localScale = new Vector3(1.1f, 1.1f, 1.1f);
			Player.Instance.maxJumpSpeed = 10f;
		}
	}
}
