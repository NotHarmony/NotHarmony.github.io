﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using IIDKQuest;
using IIDKQuest.Menu;
using MelonLoader;

[assembly: MelonInfo(typeof(IIDKQuest.Menu.Main), "IIDKQuest", "1.0.0", "iidk")]
[assembly: MelonGame()]
[assembly: AssemblyTitle("IIDKQuest")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("IIDKQuest")]
[assembly: AssemblyCopyright("Copyright ©  2024")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: Guid("d6943139-b22e-462d-85ad-6ebb79e8aa7e")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
