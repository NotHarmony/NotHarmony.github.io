﻿using System;
using IIDKQuest.Classes;
using IIDKQuest.Menu;

namespace IIDKQuest.Mods
{
	// Token: 0x0200000E RID: 14
	internal class SettingsMods
	{
		// Token: 0x06000060 RID: 96 RVA: 0x000048F6 File Offset: 0x00002AF6
		public static void EnterSettings()
		{
			Main.pageNumber = 0;
			Main.buttonsType = 1;
		}

		// Token: 0x06000061 RID: 97 RVA: 0x00004905 File Offset: 0x00002B05
		public static void EnterMovementMods()
		{
			Main.pageNumber = 0;
			Main.buttonsType = 2;
		}

		// Token: 0x06000062 RID: 98 RVA: 0x00004914 File Offset: 0x00002B14
		public static void EnterRigMods()
		{
			Main.pageNumber = 0;
			Main.buttonsType = 3;
		}

		// Token: 0x06000063 RID: 99 RVA: 0x00004923 File Offset: 0x00002B23
		public static void EnterRoomMods()
		{
			Main.pageNumber = 0;
			Main.buttonsType = 4;
		}

		// Token: 0x06000064 RID: 100 RVA: 0x00004932 File Offset: 0x00002B32
		public static void EnterFunMods()
		{
			Main.pageNumber = 0;
			Main.buttonsType = 5;
		}

		// Token: 0x06000065 RID: 101 RVA: 0x00004941 File Offset: 0x00002B41
		public static void EnterVisualMods()
		{
			Main.pageNumber = 0;
			Main.buttonsType = 6;
		}

		// Token: 0x06000066 RID: 102 RVA: 0x00004950 File Offset: 0x00002B50
		public static void EnterPresets()
		{
			Main.pageNumber = 0;
			Main.buttonsType = 7;
		}

		// Token: 0x06000067 RID: 103 RVA: 0x0000495F File Offset: 0x00002B5F
		public static void OverpoweredMods()
		{
			Main.pageNumber = 0;
			Main.buttonsType = 8;
		}

		// Token: 0x06000068 RID: 104 RVA: 0x0000496E File Offset: 0x00002B6E
		public static void RightHand()
		{
			Settings.rightHanded = true;
		}

		// Token: 0x06000069 RID: 105 RVA: 0x00004977 File Offset: 0x00002B77
		public static void LeftHand()
		{
			Settings.rightHanded = false;
		}

		// Token: 0x0600006A RID: 106 RVA: 0x00004980 File Offset: 0x00002B80
		public static void EnableFPSCounter()
		{
			Settings.fpsCounter = true;
		}

		// Token: 0x0600006B RID: 107 RVA: 0x00004989 File Offset: 0x00002B89
		public static void DisableFPSCounter()
		{
			Settings.fpsCounter = false;
		}

		// Token: 0x0600006C RID: 108 RVA: 0x00004992 File Offset: 0x00002B92
		public static void EnableNotifications()
		{
			Settings.disableNotifications = false;
		}

		// Token: 0x0600006D RID: 109 RVA: 0x0000499B File Offset: 0x00002B9B
		public static void DisableNotifications()
		{
			Settings.disableNotifications = true;
		}

		// Token: 0x0600006E RID: 110 RVA: 0x000049A4 File Offset: 0x00002BA4
		public static void EnableDisconnectButton()
		{
			Settings.disconnectButton = true;
		}

		// Token: 0x0600006F RID: 111 RVA: 0x000049AD File Offset: 0x00002BAD
		public static void DisableDisconnectButton()
		{
			Settings.disconnectButton = false;
		}

		// Token: 0x06000070 RID: 112 RVA: 0x000049B6 File Offset: 0x00002BB6
		public static void CustomMOTD()
		{
			Settings.customMotd = true;
		}

		// Token: 0x06000071 RID: 113 RVA: 0x000049BF File Offset: 0x00002BBF
		public static void CustomMOTDOff()
		{
			Settings.customMotd = false;
		}

		// Token: 0x06000072 RID: 114 RVA: 0x000049C8 File Offset: 0x00002BC8
		public static void RainbowMenu()
		{
			Settings.backgroundColor = new ExtGradient
			{
				isRainbow = true
			};
		}

		// Token: 0x06000073 RID: 115 RVA: 0x000049DC File Offset: 0x00002BDC
		public static void RainbowMenuOff()
		{
			Settings.backgroundColor = new ExtGradient
			{
				isRainbow = false
			};
		}
	}
}
