﻿using System;
using easyInputs;
using GorillaLocomotion;
using UnityEngine;

namespace IIDKQuest.Mods
{
	// Token: 0x0200000B RID: 11
	internal class RigMods
	{
		// Token: 0x06000043 RID: 67 RVA: 0x000043F0 File Offset: 0x000025F0
		public static void Noclip()
		{
			bool triggerButtonDown = EasyInputs.GetTriggerButtonDown(EasyHand.LeftHand);
			bool flag = triggerButtonDown;
			if (flag)
			{
				foreach (Collider collider in UnityEngine.Object.FindObjectsOfType<MeshCollider>())
				{
					collider.enabled = false;
				}
				foreach (Collider collider2 in UnityEngine.Object.FindObjectsOfType<BoxCollider>())
				{
					collider2.enabled = false;
				}
				foreach (Collider collider3 in UnityEngine.Object.FindObjectsOfType<SphereCollider>())
				{
					collider3.enabled = false;
				}
			}
			else
			{
				foreach (Collider collider4 in UnityEngine.Object.FindObjectsOfType<MeshCollider>())
				{
					collider4.enabled = true;
				}
				foreach (Collider collider5 in UnityEngine.Object.FindObjectsOfType<BoxCollider>())
				{
					collider5.enabled = true;
				}
				foreach (Collider collider6 in UnityEngine.Object.FindObjectsOfType<SphereCollider>())
				{
					collider6.enabled = true;
				}
			}
		}

		// Token: 0x06000044 RID: 68 RVA: 0x000045C0 File Offset: 0x000027C0
		public static void Ghost()
		{
			bool primaryButtonDown = EasyInputs.GetPrimaryButtonDown(EasyHand.RightHand);
			if (primaryButtonDown)
			{
				GorillaTagger.Instance.myVRRig.enabled = false;
				GorillaTagger.Instance.offlineVRRig.enabled = false;
			}
			else
			{
				GorillaTagger.Instance.myVRRig.enabled = true;
				GorillaTagger.Instance.offlineVRRig.enabled = true;
			}
		}

		// Token: 0x06000045 RID: 69 RVA: 0x00004624 File Offset: 0x00002824
		public static void Invis()
		{
			bool triggerButtonDown = EasyInputs.GetTriggerButtonDown(EasyHand.LeftHand);
			if (triggerButtonDown)
			{
				GorillaTagger.Instance.myVRRig.transform.position = new Vector3(100f, 100f, 100f);
				GorillaTagger.Instance.offlineVRRig.transform.position = new Vector3(100f, 100f, 100f);
				GorillaTagger.Instance.myVRRig.enabled = false;
				GorillaTagger.Instance.offlineVRRig.enabled = false;
			}
			else
			{
				GorillaTagger.Instance.offlineVRRig.enabled = true;
				GorillaTagger.Instance.myVRRig.enabled = true;
			}
		}

		// Token: 0x06000046 RID: 70 RVA: 0x000046D8 File Offset: 0x000028D8
		public static void SteamLongArms()
		{
			Player.Instance.transform.localScale = new Vector3(1.25f, 1.25f, 1.25f);
		}

		// Token: 0x06000047 RID: 71 RVA: 0x000046FF File Offset: 0x000028FF
		public static void ReallyLongArms()
		{
			Player.Instance.transform.localScale = new Vector3(1.5f, 1.5f, 1.5f);
		}

		// Token: 0x06000048 RID: 72 RVA: 0x00004726 File Offset: 0x00002926
		public static void ShortArms()
		{
			Player.Instance.transform.localScale = new Vector3(0.5f, 0.5f, 0.5f);
		}

		// Token: 0x06000049 RID: 73 RVA: 0x0000474D File Offset: 0x0000294D
		public static void ResetArms()
		{
			Player.Instance.transform.localScale = new Vector3(1f, 1f, 1f);
		}

		// Token: 0x0600004A RID: 74 RVA: 0x00004774 File Offset: 0x00002974
		public static void ResetStickArms()
		{
			Player.Instance.rightHandOffset = new Vector3(0.02f, -0.02f, -0.03f);
			Player.Instance.leftHandOffset = new Vector3(-0.02f, -0.02f, -0.03f);
		}

		// Token: 0x0600004B RID: 75 RVA: 0x000047C0 File Offset: 0x000029C0
		public static void PlaceHolder()
		{
		}

		// Token: 0x0600004C RID: 76 RVA: 0x000047C3 File Offset: 0x000029C3
		public static void SpinheadY()
		{
		}

		// Token: 0x0600004D RID: 77 RVA: 0x000047C6 File Offset: 0x000029C6
		public static void SpinheadX()
		{
		}

		// Token: 0x0600004E RID: 78 RVA: 0x000047C9 File Offset: 0x000029C9
		public static void SpazHead()
		{
		}

		// Token: 0x0600004F RID: 79 RVA: 0x000047CC File Offset: 0x000029CC
		public static void FixHeadSPin()
		{
		}

		// Token: 0x06000050 RID: 80 RVA: 0x000047D0 File Offset: 0x000029D0
		public static void QuestLong()
		{
			Player.Instance.rightHandOffset = new Vector3(0f, 0f, 0.25f);
			Player.Instance.leftHandOffset = new Vector3(0f, 0f, 0.25f);
		}
	}
}
